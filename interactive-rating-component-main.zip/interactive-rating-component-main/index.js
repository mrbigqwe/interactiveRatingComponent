function getRate(item) {
  let id = item.id;
  if (id === "rate1") {
    document.getElementById("selectedScore").innerText = "1";
    document.getElementById("ratingPage").style.display = "none";
    document.getElementById("thankPage").style.display = "block";
  } else if (id === "rate2") {
    document.getElementById("selectedScore").innerText = "2";
    document.getElementById("ratingPage").style.display = "none";
    document.getElementById("thankPage").style.display = "block";
  } else if (id === "rate3") {
    document.getElementById("selectedScore").innerText = "3";
    document.getElementById("ratingPage").style.display = "none";
    document.getElementById("thankPage").style.display = "block";
  } else if (id === "rate4") {
    document.getElementById("selectedScore").innerText = "4";
    document.getElementById("ratingPage").style.display = "none";
    document.getElementById("thankPage").style.display = "block";
  } else if (id === "rate5") {
    document.getElementById("selectedScore").innerText = "5";
    document.getElementById("ratingPage").style.display = "none";
    document.getElementById("thankPage").style.display = "block";
  }
}
